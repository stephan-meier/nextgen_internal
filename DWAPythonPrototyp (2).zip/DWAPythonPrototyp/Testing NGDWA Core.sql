USE NGDWA

select *
from stg.dim_Patient
go

exec [stg].[usp_dim_Patient_full_load] 1
go

select *
from stg.dim_Patient
go

exec [stg].[usp_dim_Patient_dummy] 1
go

select *
from stg.dim_Patient
go

exec [stg].[usp_dim_Patient_delete_detection] 1
go

select *
from stg.dim_Patient
go

-- Test Case 1:
-- 1te Ausf�hrung
-- Erwartung: Alle records werden in DWH geschrieben
select *
from dwh.dim_Patient
go

exec [stg].[usp_dim_Patient_historization] 1, '1900-01-01 00:00:00', '2023-08-07 01:00:00', null
go

select *
from dwh.dim_Patient
go

-- Test Case 2:
-- 2te Ausf�hrung
-- Erwartung: keine neuen Records
exec [stg].[usp_dim_Patient_historization] 2, '1900-01-01 00:00:00', '2023-08-07 02:00:00', null

select *
from dwh.dim_Patient
go

-- Test Case 3:
-- Update recrod in stage table, um historisierung zu simulieren
-- Erwartung: Record wird historisiert
update stg.dim_Patient
set FirstName = 'Test Case 3: Update SCD2 Feld'
where dim_Patient_bk = '0000050570'
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_historization] 3, '1900-01-01 00:00:00.000', '2023-08-07 03:00:00', null
go

select *
from dwh.dim_Patient
where dim_Patient_bk = '0000050570'
go

-- Test Case 4:
-- Delete recrod in source table, um delete detection zu simulieren
-- Erwartung: 1 Record wird in stage Tabelle als deleted markiert und in der DWH Tabelle historisiert
ALTER view [stg].[v_dim_Patient_91] as
select
     dim_Patient_bk = isNULL(dim_Patient_bk, '-1')
    ,dim_SourceSystem_bk = isNULL(dim_SourceSystem_bk, '-1')
    ,FirstName = isNULL(FirstName, '#NA#')
    ,LastName = isNULL(LastName, '#NA#')
    ,BirthDate = isNULL(BirthDate, NULL)
    , dim_Date_BirthDate_bk = isNULL(CAST(BirthDate as date), NULL)
    , dim_Time_BirthDate_bk = isNULL(CAST(BirthDate as time), NULL)
    ,dim_Country_ResidenceCountry_bk = isNULL(dim_Country_ResidenceCountry_bk, '-1')
    ,dim_Country_BirthCountry_bk = isNULL(dim_Country_BirthCountry_bk, '-1')
    ,dim_Country_CitizenshipCountry_bk = isNULL(dim_Country_CitizenshipCountry_bk, '-1')
    ,GestationalAgeInDays = isNULL(GestationalAgeInDays, NULL)
from stg.v_dim_Patient_90
where dim_Patient_bk <> '0000050570'
go

select *
from stg.v_dim_Patient_91
where dim_Patient_bk = '0000050570'
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_full_load] 4
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_dummy] 4
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_delete_detection] 4
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

-- History
select *
from dwh.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_historization] 4, '1900-01-01 00:00:00', '2023-08-07 04:00:00', null
go

select *
from dwh.dim_Patient
where dim_Patient_bk = '0000050570'
go

-- Test Case 5:
-- Reaktivierung Delete recrod in source table, um Reaktivierunng eines delete records zu simulieren
-- Erwartung: 1 Record wird in der DWH Tabelle historisiert
ALTER view [stg].[v_dim_Patient_91] as
select
     dim_Patient_bk = isNULL(dim_Patient_bk, '-1')
    ,dim_SourceSystem_bk = isNULL(dim_SourceSystem_bk, '-1')
    ,FirstName = isNULL(FirstName, '#NA#')
    ,LastName = isNULL(LastName, '#NA#')
    ,BirthDate = isNULL(BirthDate, NULL)
    , dim_Date_BirthDate_bk = isNULL(CAST(BirthDate as date), NULL)
    , dim_Time_BirthDate_bk = isNULL(CAST(BirthDate as time), NULL)
    ,dim_Country_ResidenceCountry_bk = isNULL(dim_Country_ResidenceCountry_bk, '-1')
    ,dim_Country_BirthCountry_bk = isNULL(dim_Country_BirthCountry_bk, '-1')
    ,dim_Country_CitizenshipCountry_bk = isNULL(dim_Country_CitizenshipCountry_bk, '-1')
    ,GestationalAgeInDays = isNULL(GestationalAgeInDays, NULL)
from stg.v_dim_Patient_90
go

select *
from stg.v_dim_Patient_91
where dim_Patient_bk = '0000050570'
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_full_load] 5
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_dummy] 5
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_delete_detection] 5
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000050570'
go

-- History
select *
from dwh.dim_Patient
where dim_Patient_bk = '0000050570'
go

exec [stg].[usp_dim_Patient_historization] 5, '1900-01-01 00:00:00', '2023-08-07 05:00:00', null
go

select *
from dwh.dim_Patient
where dim_Patient_bk = '0000050570'
go

-- Test Case 6:
-- Early Arrive im DWH vorhanden. Richtiger Record kommt weiterhin nicht aus Stage
-- Erwartung: keine delete detection, keine Historisierung
update dwh.dim_Patient
set  dwh_EarlyArriveFlag				= 1
	,dwh_EarlyArriveField				= 'Testtable.TestCase6'
	,FirstName							= '#NA#'
	,LastName							= '#NA#'
	,BirthDate							= null
	,dim_Date_BirthDate_bk				= '-1'
	,dim_Time_BirthDate_bk				= '-1'
	,dim_Country_ResidenceCountry_bk	= '-1'
	,dim_Country_BirthCountry_bk		= '-1'
	,dim_Country_CitizenshipCountry_bk	= '-1'
	,GestationalAgeInDays				= null
where dim_Patient_bk = '0000105352'
go

ALTER view stg.v_dim_Patient_91 as
select
     dim_Patient_bk = isNULL(dim_Patient_bk, '-1')
    ,dim_SourceSystem_bk = isNULL(dim_SourceSystem_bk, '-1')
    ,FirstName = isNULL(FirstName, '#NA#')
    ,LastName = isNULL(LastName, '#NA#')
    ,BirthDate = isNULL(BirthDate, NULL)
    , dim_Date_BirthDate_bk = isNULL(CAST(BirthDate as date), NULL)
    , dim_Time_BirthDate_bk = isNULL(CAST(BirthDate as time), NULL)
    ,dim_Country_ResidenceCountry_bk = isNULL(dim_Country_ResidenceCountry_bk, '-1')
    ,dim_Country_BirthCountry_bk = isNULL(dim_Country_BirthCountry_bk, '-1')
    ,dim_Country_CitizenshipCountry_bk = isNULL(dim_Country_CitizenshipCountry_bk, '-1')
    ,GestationalAgeInDays = isNULL(GestationalAgeInDays, NULL)
from stg.v_dim_Patient_90
where dim_Patient_bk <> '0000105352'
go

select *
from stg.v_dim_Patient_91
where dim_Patient_bk = '0000105352'
go

select *
from dwh.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_full_load] 6
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_dummy] 6
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_delete_detection] 6
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000105352'
go

-- History
select *
from dwh.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_historization] 6, '1900-01-01 00:00:00', '2023-08-07 06:00:00', null
go

select *
from dwh.dim_Patient
where dim_Patient_bk = '0000105352'
go

-- Test Case 7:
-- Early Arrive im DWH vorhanden. Richtiger Record kommt aus Stage
-- Erwartung: 1 Historisierung
update dwh.dim_Patient
set  dwh_EarlyArriveFlag				= 1
	,dwh_EarlyArriveField				= 'Testtable.TestCase6'
	,FirstName							= '#NA#'
	,LastName							= '#NA#'
	,BirthDate							= null
	,dim_Date_BirthDate_bk				= '-1'
	,dim_Time_BirthDate_bk				= '-1'
	,dim_Country_ResidenceCountry_bk	= '-1'
	,dim_Country_BirthCountry_bk		= '-1'
	,dim_Country_CitizenshipCountry_bk	= '-1'
	,GestationalAgeInDays				= null
where dim_Patient_bk = '0000105352'
go

ALTER view stg.v_dim_Patient_91 as
select
     dim_Patient_bk = isNULL(dim_Patient_bk, '-1')
    ,dim_SourceSystem_bk = isNULL(dim_SourceSystem_bk, '-1')
    ,FirstName = isNULL(FirstName, '#NA#')
    ,LastName = isNULL(LastName, '#NA#')
    ,BirthDate = isNULL(BirthDate, NULL)
    , dim_Date_BirthDate_bk = isNULL(CAST(BirthDate as date), NULL)
    , dim_Time_BirthDate_bk = isNULL(CAST(BirthDate as time), NULL)
    ,dim_Country_ResidenceCountry_bk = isNULL(dim_Country_ResidenceCountry_bk, '-1')
    ,dim_Country_BirthCountry_bk = isNULL(dim_Country_BirthCountry_bk, '-1')
    ,dim_Country_CitizenshipCountry_bk = isNULL(dim_Country_CitizenshipCountry_bk, '-1')
    ,GestationalAgeInDays = isNULL(GestationalAgeInDays, NULL)
from stg.v_dim_Patient_90
go

select *
from stg.v_dim_Patient_91
where dim_Patient_bk = '0000105352'
go

select *
from dwh.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_full_load] 7
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_dummy] 7
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_delete_detection] 7
go

select *
from stg.dim_Patient
where dim_Patient_bk = '0000105352'
go

-- History
select *
from dwh.dim_Patient
where dim_Patient_bk = '0000105352'
go

exec [stg].[usp_dim_Patient_historization] 7, '1900-01-01 00:00:00', '2023-08-07 07:00:00', null
go

select *
from dwh.dim_Patient
where dim_Patient_bk = '0000105352'
go