# -*- coding: utf-8 -*-
"""
Created on Mon Aug 14 06:58:36 2023

@author: steph
"""

# WICHTIG: ein Unterverzeichnis 'base' muss schon existieren!

# Annahme: jede Tabelle hat maximal einen Index (PK)!! Bis jetzt ist das in CDWH so.
# Annahme: jeder PK besteht aktuell aus einem Feld. Das gilt nur für das aktuelle CDMH Modell. Entsprechend ist das Parsing einfacher aufgebaut. 
#          Die Generatortemplates können auch zusammengesetzte PKs abbilden.

import xmltodict
import json
import pprint
import pyodbc
from datetime import datetime as dt

doExecute = True
printInfo = False

#xmlInFile = "./PDM_LOAD_SAP_ISH.pdm"
xmlInFile = "./PDM_CDMH_NGDWA.pdm"

table_list = []

def remove_nested_keys(dictionary, keys_to_remove):
    # Key Values aus Dictionary löschen, wird für at_id (PKs) benötigt
    new_dict = {}

    for key, value in dictionary.items():
        if key not in keys_to_remove:
            if isinstance(value, dict):
                new_dict[key] = remove_nested_keys(value, keys_to_remove)
            else:
                new_dict[key] = value

    return new_dict


def generate_sql_table_insert(data):
    table_name = "dbo.NGDWA_Table"

    # Erstellen Sie Listen für die Spaltennamen und ihre Werte
    columns = []
    values = []

    for key, value in data.items():
        # Nur Spalten, die in der Tabelle vorhanden sind, berücksichtigen
        if key in ["SchemaName", "TableName", "Description", "TableArea", "IsScd2HistoryTable",
                   "HasDeleteDetection", "HasDummyRecord", "IsDeltaLoad", "DeltaLoadType",
                   "DeltaColumnName", "DeltaFilterExpression", "InsertDateTime"]:
            columns.append(key)
            # Überprüfen, ob der Wert eine Zeichenkette ist und entsprechend anführen
            if isinstance(value, str):
                values.append(f"'{value}'")
            else:
                values.append(str(value))

    columns_str = ", ".join(columns)
    values_str = ", ".join(values)

    # Erstellen Sie den INSERT-Befehl
    sql = f"INSERT INTO {table_name} ({columns_str}) VALUES ({values_str});"
    return sql

def generate_sql_column_insert(data):
    table_name = "dbo.NGDWA_TableColumns"

    # Erstellen Sie Listen für die Spaltennamen und ihre Werte
    columns = []
    values = []

    for key, value in data.items():
        # Nur Spalten, die in der Tabelle vorhanden sind, berücksichtigen
        if key in ["SchemaName", "TableName", "ColumnName", "Description", "DataType",
                   "ColumnOrder", "IsMandatory", "IsBk", "HasDateDimension",
                   "EarlyArriveParentTable", "InsertDateTime"]:
            columns.append(key)
            # Überprüfen, ob der Wert eine Zeichenkette ist und entsprechend anführen
            if isinstance(value, str):
                values.append(f"'{value}'")
            else:
                values.append(str(value))

    columns_str = ", ".join(columns)
    values_str = ", ".join(values)

    # Erstellen Sie den INSERT-Befehl
    sql = f"INSERT INTO {table_name} ({columns_str}) VALUES ({values_str});"
    return sql

def execute_statements(sql_script):
    # init DB Connection
    server = "itxchdm.switzerlandnorth.cloudapp.azure.com"
    database = "NGDWA_Metadata_Repository"
    username = "chdm"
    password = "IT-Logix32"

    ret = 0

    if doExecute:

        try:
            conn = pyodbc.connect(
                "DRIVER={SQL Server};SERVER=" + server + ";DATABASE=" + database + ";UID=" + username + ";PWD=" + password)

            # Template SQL Ausführung
            # sql = "select count(*) cnt from dwh.dim_Patient"
            # cursor = conn.cursor()
            # result = pd.read_sql_query(sql, conn)
            # cnt = int(result.cnt[0])
            # print("count: " + str(cnt))
            # cursor.close()

            # cursor = conn.cursor()
            # cursor.execute(script)
            with conn.cursor() as cursor:
                for statement in sql_script.split(";"):
                    if printInfo:
                        print(statement)
                    if len(statement) > 0:
                        cursor.execute(statement)
                        conn.commit()
        except pyodbc.DataError as err:
            ret = 'pyodbc: Data Error! '  + err.args[1]
            print(ret)
            print(statement)
        except pyodbc.OperationalError as err:
            ret = 'pyodbc: Operational Error! '  + err.args[1]
            print(ret)
            print(statement)
        except pyodbc.IntegrityError as err:
            ret = 'pyodbc: Integrity Error! ' + err.args[1]
            print(ret)
            print(statement)
        except pyodbc.InternalError as err:
            ret = 'pyodbc: Internal Error! ' + err.args[1]
            print(ret)
            print(statement)
        except pyodbc.ProgrammingError as err:
            ret = 'pyodbc: Programming Error! ' + err.args[1]
            print(ret)
            print(statement)
        except pyodbc.NotSupportedError as err:
            ret = 'pyodbc: NotSupported Error! ' + err.args[1]
            print(ret)
            print(statement)
        else:
            cursor.close()
            conn.close()
    else:
        print('--- SQL Script Start ------------------------------------------------')
        print(sql_script)
        print('--- SQL Script End ------------------------------------------------')

    return ret

def get_extended_attribute_value(ext, attr):

    #if printInfo:
    #    print(ext)
    ext_split = ext.split(",")
    #if printInfo:
    #    print(ext_split)
    # attr: NGDWA_TableArea
    if attr in ext and attr == "NGDWA_TableArea":
        ext_split_index = ext_split.index('NGDWA_TableArea') + 1
        if (ext_split[ext_split_index].find('LOAD') >= 0):
            value = 'LOAD'
        elif (ext_split[ext_split_index].find('PSA') >= 0):
            value = 'PSA'
        elif (ext_split[ext_split_index].find('CORE') >= 0):
            value = 'CORE'
        else:
            value = '0'

    # attr: NGDWA_IsScd2HistoryTable
    elif attr in ext and attr == "NGDWA_IsScd2HistoryTable":
        ext_split_index = ext_split.index('NGDWA_IsScd2HistoryTable') + 1
        if (ext_split[ext_split.index('NGDWA_IsScd2HistoryTable') + 1].find('true') >= 0):
            value = '1'
        else:
            value = '0'

    # attr: NGDWA_HasDeleteDetection
    elif attr in ext and attr == "NGDWA_HasDeleteDetection":
        ext_split_index = ext_split.index('NGDWA_HasDeleteDetection') + 1
        if (ext_split[ext_split.index('NGDWA_HasDeleteDetection') + 1].find('true') >= 0):
            value = '1'
        else:
            value = '0'

    # attr: NGDWA_HasDummyRecord
    elif attr in ext and attr == "NGDWA_HasDummyRecord":
        ext_split_index = ext_split.index('NGDWA_HasDummyRecord') + 1
        if (ext_split[ext_split.index('NGDWA_HasDummyRecord') + 1].find('true') >= 0):
            value = '1'
        else:
            value = '0'

    # attr: NGDWA_IsDeltaLoad
    elif attr in ext and attr == "NGDWA_IsDeltaLoad":
        ext_split_index = ext_split.index('NGDWA_IsDeltaLoad') + 1
        if (ext_split[ext_split.index('NGDWA_IsDeltaLoad') + 1].find('true') >= 0):
            value = '1'
        else:
            value = '0'

    # attr: NGDWA_DeltaLoadType
    elif attr in ext and attr == "NGDWA_DeltaLoadType":
        ext_split_index = ext_split.index('NGDWA_DeltaLoadType') + 1
        if (ext_split[ext_split_index].find('PREDELETE') >= 0):
            value = 'PREDELETE'
        elif (ext_split[ext_split_index].find('MERGE') >= 0):
            value = 'MERGE'
        else:
            value = '0'

    # attr: NGDWA_DeltaColumnName
    elif attr in ext and attr == "NGDWA_DeltaColumnName":
        #if printInfo:
            #print(ext)
        ext_split = ext.split('NGDWA_')
        #if printInfo:
            #print(ext_split)
        value_unparsed = [s for s in ext_split if "DeltaColumnName" in s]
        value = str(value_unparsed).split("=")[1].split("{")[0]
        value = str(value).replace("\\n", "")
        #if printInfo:
            #print(value)

    # attr: NGDWA_DeltaFilterExpression
    elif attr in ext and attr == "NGDWA_DeltaFilterExpression":
        #if printInfo:
            #print(ext)
        ext_split = ext.split('NGDWA_')
        #if printInfo:
            #print(ext_split)
        value_unparsed = [s for s in ext_split if "DeltaFilterExpression" in s]
        value = str(value_unparsed).split("=")[1].split("{")[0]
        value = str(value).replace("\\n","")
        #if printInfo:
            #print(value)

    # attr: NGDWA_HasDateDimension
    elif attr in ext and attr == "NGDWA_HasDateDimension":
        ext_split_index = ext_split.index('NGDWA_HasDateDimension') + 1
        if (ext_split[ext_split.index('NGDWA_HasDateDimension') + 1].find('true') >= 0):
            value = '1'
        else:
            value = '0'

    else:
        value = '0'
        #if printInfo:
            #print("attr: " + attr + " / not found")

    #if printInfo:
        #print("attr: " + attr + " / value: " + value)
    return value


with open(xmlInFile, encoding='utf-8') as fd:
    doc = xmltodict.parse(fd.read(), process_namespaces=True)
    
def get_table_name(reference):
    reference = str(reference)
    reference = reference.replace("{", "").replace("}", "").replace("Ref", "Id")

    m_tables = doc["Model"]["object:RootObject"]["collection:Children"]["object:Model"]["collection:Tables"]
    i = 0
    for table in m_tables["object:Table"]:
        if reference in str(table):
            table_name = table["attribute:Name"]
            i = i + 1

    if i == 1:
        return table_name
    else:
        table_name = 'error'
        return table_name

m_t = doc["Model"]["object:RootObject"]["collection:Children"]["object:Model"]["collection:Tables"]
m_u = doc["Model"]["object:RootObject"]["collection:Children"]["object:Model"]["collection:Users"]

SchemaName = m_u["object:User"]["attribute:Code"]

for t in m_t["object:Table"]:
    current_time = dt.now().strftime('%Y-%m-%d %H:%M:%S')
    TableName = t["attribute:Name"]
    print('--- Table ' + TableName + ' start ----------------------------------------------------------------')
    nt = {'SchemaName' : '',
          'TableName' : '',
          'at_id': '',
          'Description': '',
          'TableArea': '',
          'IsScd2HistoryTable': '',
          'HasDeleteDetection': '',
          'HasDummyRecord': '',
          'IsDeltaLoad': '',
          'DeltaLoadType': '',
          'DeltaColumnName': '',
          'DeltaFilterExpression': '',
          'InsertDateTime': ''}
    nt["SchemaName"] = SchemaName
    nt["TableName"] = t["attribute:Code"]
    nt["at_id"] = t["@Id"]
    if 'attribute:Comment' in t:
        # Replace is needed due to handling simple quotes (') and semicolon (;) in the SQL statement
        nt["Description"] = t["attribute:Comment"].replace("'", "''").replace(";", ",")
    else:
        nt["Description"] = ''
    ##### get extended attributes start #####
    ext = t["attribute:ExtendedAttributesText"]
    nt["TableArea"]                 = get_extended_attribute_value(ext, 'NGDWA_TableArea')
    nt["IsScd2HistoryTable"]        = get_extended_attribute_value(ext, 'NGDWA_IsScd2HistoryTable')
    nt["HasDeleteDetection"]        = get_extended_attribute_value(ext, 'NGDWA_HasDeleteDetection')
    nt["HasDummyRecord"]            = get_extended_attribute_value(ext, 'NGDWA_HasDummyRecord')
    nt["IsDeltaLoad"]               = get_extended_attribute_value(ext, 'NGDWA_IsDeltaLoad')
    nt["DeltaLoadType"]             = get_extended_attribute_value(ext, 'NGDWA_DeltaLoadType')
    nt["DeltaColumnName"]           = get_extended_attribute_value(ext, 'NGDWA_DeltaColumnName')
    nt["DeltaFilterExpression"]     = get_extended_attribute_value(ext, 'NGDWA_DeltaFilterExpression')
    ##### get extended attributes end #####

    nt["InsertDateTime"] = current_time

    # get Primary Key Collumn Collection
    if 'collection:Keys' in t:
        Keys = t["collection:Keys"]["object:Key"]["collection:Key.Columns"]
    else:
        Keys = ''

    # Important: Column Delte before Table delete
    #if printInfo:
        #print(nt)
    # TODO: Transaction handling, vgl. weiter unten
    sql_column_delete = "DELETE FROM dbo.NGDWA_TableColumns WHERE SchemaName = '" + nt["SchemaName"] + "' AND TableName = '" + nt["TableName"] + "'"
    execute_statements(sql_column_delete)
    sql_table_delete = "DELETE FROM dbo.NGDWA_Table WHERE SchemaName = '" + nt["SchemaName"] + "' AND TableName = '" + nt["TableName"] + "'"
    execute_statements(sql_table_delete)
    sql_table_insert = generate_sql_table_insert(nt)
    execute_statements(sql_table_insert)

    # Column Order Counter
    i = 1
    for c in t["collection:Columns"]["object:Column"]:
        ColumnId = c["@Id"]
        nf = {'SchemaName': '',
              'TableName': '',
              'ColumnName': '',
              'at_id': '',
              'Description': '',
              'DataType': '',
              'ColumnOrder': '',
              'IsMandatory': '',
              'IsBk': '',
              'HasDateDimension': '',
              'EarlyArriveParentTable': '',
              'InsertDateTime': ''}
        nf["SchemaName"] = SchemaName
        nf["TableName"] = t["attribute:Code"]
        nf["ColumnName"] = c["attribute:Code"]
        nf["at_id"] = c["@Id"]
        if 'attribute:Comment' in c:
            # Replace is needed due to handling simple quotes (') and semicolon (;) in the SQL statement
            nf["Description"] = c["attribute:Comment"].replace("'", "''").replace(";", ",")
        else:
            nf["Description"] = ''
        nf["DataType"] = c["attribute:DataType"]
        nf["ColumnOrder"] = i
        if 'attribute:Column.Mandatory' in c:
            nf["IsMandatory"] = c["attribute:Column.Mandatory"]
        else:
            nf["IsMandatory"] = '0'
        if 'attribute:ExtendedAttributesText' in c:
            ext = c["attribute:ExtendedAttributesText"]
        else:
            ext = ''
        if ColumnId in str(Keys):
            nf["IsBk"] = '1'
        else:
            nf["IsBk"] = '0'

        nf["HasDateDimension"] = get_extended_attribute_value(ext, 'NGDWA_HasDateDimension')
        if 'NGDWA_EarlyArriveParentTable' in str(c):
            try:
                TableId = c["collection:ExtendedCollections"]["object:ExtendedCollection"]["collection:Content"]["object:Table"]
                # TODO: die get_table_name könnte sicherlich noch etwas eleganter implementiert werden
                RefTableName = get_table_name(TableId)
                nf["EarlyArriveParentTable"] = RefTableName
            except:
                print("error: " + str(c))
                nf["EarlyArriveParentTable"] = "error"

        nf["InsertDateTime"] = current_time

        # Column Order Counter
        i = i + 1

        #if printInfo:
            #print(nf)
        # TODO: Transaction handling
        sql_column_insert = generate_sql_column_insert(nf)
        execute_statements(sql_column_insert)

    print('--- Table ' + TableName + ' end ----------------------------------------------------------------')
    

        
