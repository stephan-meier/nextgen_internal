Diese Repository beinhaltet den Prototypen eines DWH Generators auf Basis dieser Komponenten:
- Modellierung: SAP Powerdesigner
- Metadata Connector zum NGDWA Repository: Python (NGDWA_RepoImport.py)
- DWH Core Generator: Python auf Basis Jinja2 (NGDWA_Generator.py)
- DAG für Airflow: Python (TODO)
- Datenmodelle Metadata Repository und CDMH im CDMH Powerdesigner Repository. Installation Siehe: https://itxad.sharepoint.com/:t:/s/LP2-Healthcare/EUcmr9PPQjpJjelK2Nkv7bkBkElRw7YU10qcgg5DOWA0Eg?e=xHdhDu

Vorgehen für Python Umgebung:
-----------------------------
1) Download Python Umgebung
2) Download PyCharm
3) Neues Projekt erstellen


vorgehen, um das Metadata Repository zu laden:
----------------------------------------------
1) Datenmodell NGDWA_Repository\PDM_NGDWA_Metadata_Repository aus dem zentralen Repo runterladen
2) Database > Generate Database... > SQL-Skript in einer DB installieren (muss nicht wiederholt werden, da das Repo bereits hier installiert ist: itxchdm.switzerlandnorth.cloudapp.azure.com / NGDWA_Metadata_Repository)

Vorgehen, um Datenmodell in Metadata Repository zu laden:
---------------------------------------------------------
1) Download NGDWA_RepoImport.py von diesem Repo
2) Datenmodell NGDWA_CDMH\PDM_CDMH_NGDWA aus dem zentralen Repo runterladen
3) NGDWA_RepoImport.py ausführen
    - zuoberst im Skript doExecute = True setzen --> dies führt die SQL Stamtements in der DB aus. ACHTUNG: bitte vorsichtig einsetzen und mit Teamkollegen Rücksprache nehmen
4) Datenmodell NGDWA_DataSources\PDM_LOAD_SAP_ISH aus dem zentralen Repo runterladen
5) NGDWA_RepoImport.py ausführen
    - zuoberst im Skript doExecute = True setzen --> dies führt die SQL Stamtements in der DB aus. ACHTUNG: bitte vorsichtig einsetzen und mit Teamkollegen Rücksprache nehmen
    - zuoberst im Skript Datenmodell umkommentieren von "./PDM_CDMH_NGDWA.pdm" auf "./PDM_LOAD_SAP_ISH.pdm"

Vorgehen, um den Code Generator auszuführen:
--------------------------------------------
1) Download NGDWA_Generator.py von diesem Repo
2) NGDWA_Generator.py ausführen
    - zuoberst im Skript doExecute = True setzen --> dies führt die SQL Stamtements in der DB aus. ACHTUNG: bitte vorsichtig einsetzen und mit Teamkollegen Rücksprache nehmen

OPEN:
-----
- Python Generator als Batch-Skript ausführen machen.
- PSA einbauen und parametrierbar machen (PSA/DWH)